var searchData=
[
  ['degreerotation',['degreeRotation',['../classTriangle.html#ad55bc6fb720a4a4bd9ae286b08f711d7',1,'Triangle']]],
  ['display',['display',['../classDisplay.html#a9bae38dcb3346b7d4fc5718824e7d50b',1,'Display']]],
  ['displayheight',['displayHeight',['../classMySimulator.html#ace48d7265f8ee2936133aa84e15ab726',1,'MySimulator::displayHeight()'],['../classSimulatorTestFixture.html#a72d0b4e6256efa386ab0620f8d47b909',1,'SimulatorTestFixture::displayHeight()']]],
  ['displaywidth',['displayWidth',['../classMySimulator.html#a5ec51fd929d6b63e8653e23b78e63e85',1,'MySimulator::displayWidth()'],['../classSimulatorTestFixture.html#a1222783eed30f0984957b4b750276166',1,'SimulatorTestFixture::displayWidth()']]]
];
