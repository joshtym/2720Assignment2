var searchData=
[
  ['getallegrodisplay',['getAllegroDisplay',['../classDisplay.html#adb0dbf3d9ba0d6e8a00f2ff00b48b28c',1,'Display']]],
  ['geth',['getH',['../classDisplay.html#a9878946b8495c15a2292bbc73800a19e',1,'Display']]],
  ['getmaxx',['getMaxX',['../classShape.html#a6ad58fe07576b1d5acaca54375f76b91',1,'Shape']]],
  ['getmaxy',['getMaxY',['../classShape.html#a3c1a966c9e6074181f6dcd649abb68ee',1,'Shape']]],
  ['getminx',['getMinX',['../classShape.html#a95d90a0e3e5de627ec8f6f5527e6721f',1,'Shape']]],
  ['getminy',['getMinY',['../classShape.html#ac6b95c7732bea254f8d73f725082169d',1,'Shape']]],
  ['getw',['getW',['../classDisplay.html#a0805ad3718988656faee6652a5fa0d87',1,'Display']]],
  ['getx',['getX',['../classPoint.html#af52a20a376f8f31e87658837565d3812',1,'Point::getX()'],['../classVector.html#abaf2f6de1a2d1d8c05167cae8311c41f',1,'Vector::getX()']]],
  ['gety',['getY',['../classPoint.html#aac5008459bf0e0053ce744a69187bae7',1,'Point::getY()'],['../classVector.html#a2cb972d66d108cb8e9598f2a202a1f27',1,'Vector::getY()']]]
];
