var searchData=
[
  ['x',['x',['../classPoint.html#ab99c56589bc8ad5fa5071387110a5bc7',1,'Point::x()'],['../classVector.html#a133722e00601091cb2075219da5da6e4',1,'Vector::x()']]]
];
