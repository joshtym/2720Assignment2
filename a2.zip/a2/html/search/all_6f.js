var searchData=
[
  ['origin',['origin',['../classShape.html#a56034fc695f29bfd5f34c71ab0994ae6',1,'Shape']]]
];
