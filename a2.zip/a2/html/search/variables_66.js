var searchData=
[
  ['framespersec',['framesPerSec',['../classSimulator.html#a0eaa1a80a589640a2b601c10e3b07882',1,'Simulator']]]
];
