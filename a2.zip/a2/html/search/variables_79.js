var searchData=
[
  ['y',['y',['../classPoint.html#afa38be143ae800e6ad69ce8ed4df62d8',1,'Point::y()'],['../classVector.html#a09a21a140718f234eea348d5058cee0b',1,'Vector::y()']]]
];
