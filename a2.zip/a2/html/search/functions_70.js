var searchData=
[
  ['point',['Point',['../classPoint.html#ad92f2337b839a94ce97dcdb439b4325a',1,'Point::Point()'],['../classPoint.html#abfbe6fc2b7734f76813e94d84b267915',1,'Point::Point(double userX)'],['../classPoint.html#abb7dbb19fabeebcb80a7fd964c9467d1',1,'Point::Point(double userX, double userY)']]]
];
