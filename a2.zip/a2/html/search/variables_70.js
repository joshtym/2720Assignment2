var searchData=
[
  ['p1',['p1',['../classTriangle.html#aa926b8e5d7cfbb0573cb1675e3ea42ba',1,'Triangle']]],
  ['p2',['p2',['../classTriangle.html#af80c672024bc54d1cebab93eec508666',1,'Triangle']]]
];
