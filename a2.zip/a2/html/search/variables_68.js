var searchData=
[
  ['height',['height',['../classDisplay.html#a9446c52846cfb434f0940f9fad9f8e88',1,'Display']]]
];
