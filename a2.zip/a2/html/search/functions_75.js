var searchData=
[
  ['updatemaxandmin',['updateMaxAndMin',['../classCircle.html#a24eeacb9302245bea98bf450e1d7e174',1,'Circle::updateMaxAndMin()'],['../classShape.html#a3801a3445e79e830c760b736779796d0',1,'Shape::updateMaxAndMin()'],['../classSquare.html#ad0f5cdf9952f69712daa241816456ded',1,'Square::updateMaxAndMin()'],['../classTriangle.html#aa7e0c08229a6f48a04ad27d8f1033d84',1,'Triangle::updateMaxAndMin()']]],
  ['updatemodel',['updateModel',['../classMySimulator.html#aaed33e2fc8706d5c86cbc8fcfb2dd1ae',1,'MySimulator::updateModel()'],['../classSimulator.html#a78e300570318b9cd65f52b9547dee070',1,'Simulator::updateModel()'],['../classSimulatorTestFixture.html#ac3c013f083cba9332570f2f35db31ebb',1,'SimulatorTestFixture::updateModel()']]]
];
