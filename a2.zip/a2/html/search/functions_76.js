var searchData=
[
  ['vector',['Vector',['../classVector.html#a6f80c73b5f18dcf3f8e36065bdc8b9e5',1,'Vector::Vector()'],['../classVector.html#a8da3c88ce079d1c2589f8422a15804e5',1,'Vector::Vector(double userX)'],['../classVector.html#a5b0cf254d7bad26e4096d7f26e47b011',1,'Vector::Vector(double userX, double userY)']]]
];
