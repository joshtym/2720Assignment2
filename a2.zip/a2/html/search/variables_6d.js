var searchData=
[
  ['maximum',['maximum',['../classShape.html#aa17b3833d457e20c67c2ffb8b5396b0b',1,'Shape']]],
  ['minimum',['minimum',['../classShape.html#a26d069b4f6de47304b5eb0e910f7684b',1,'Shape']]]
];
