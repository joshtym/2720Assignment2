#!/bin/bash
# exports the environment variable LD_LIBRARY_PATH so that the shared
# allegro libraries are found by the executable you built
# run the command "source config.sh"
# OBS: any previous definitions are cleared; change the command if
# this is not desired

export LD_LIBRARY_PATH=/home/lib2720/allegro5/lib/
